#!/bin/bash 

rm -f log/*
rm -f error/*
rm -f output/*
