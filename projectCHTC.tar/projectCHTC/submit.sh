#command to submit the job using condor_submit
condor_submit submit.sub
